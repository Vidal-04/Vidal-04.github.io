
The purpose of my website is to offer my skills and interests to whoever visits my site. 
Secondly, it focuses on my future career which is video game development. My website features three pages, 
Home Page, Career Page, Interest Page. All three pages have a navigation bar so that the person can go from a 
specific page to a different specific page. There are multiple pictures which are referenced below and 5 links. 
There are video files and video links which are referenced below. There is a Fav and Head icon. This website also 
informs the individual about computer development.



Index.html contents:
[1] “A photo of me” which is located – index.html line 20.
[2] Vidal, J. (2021) SMUG.MP4, YouTube. YouTube. Available at: https://www.youtube.com/watch?v=VEqtqG039ZA (Accessed: February 9, 2023). Which is located in: index.html – line 46.
[3] Horizons, T. (no date) Teacher horizons, Teacher Horizons. Abu Dhabi Grammar School Available at: https://www.teacherhorizons.com/static/mediav2/schools/3982/images/535445_main.jpg (Accessed: February 9, 2023). Which is located in: index.html line 54.

career.html contents:
[4] project, "C.through E.U.S.B.S.R. (no date) "it is a good start if you like playing games" – working as a game developer in the Baltic Sea Region, EUSBSR. Available at: https://www.balticsea-region-strategy.eu/news-room/highlights-blog/item/85-it-is-a-good-start-if-you-like-playing-games-working-as-a-game-developer-in-the-baltic-sea-region (Accessed: February 9, 2023). Which is located in: career.html - line 21.
[5] Wikipedia (2023) Unity (Game Engine), Wikipedia. Wikimedia Foundation. Available at: https://en.wikipedia.org/wiki/Unity_%28game_engine%29 (Accessed: February 9, 2023). Which is located in: career.html – line 71.
[6] O., W. (2022) Roblox-4 - reviews: Tushen #1 Don Gwaji, Bita, Sharhi da Labarai, Reviews. Available at: https://reviews.tn/ha/roblox-studio-comment-creer-vos-propres-jeux-roblox/roblox-4/ (Accessed: February 9, 2023). Which is located in: career.html – line 77.

interests.html contents:
[7] Percy Jackson and the olympians, book One the lightning thief (Percy Jackson and the olympians, book one): Riordan, Rick: 9780786838653: Books (June 28, 2005) Percy Jackson and the Olympians, Book One The Lightning Thief (Percy Jackson and the Olympians, Book One): Riordan, Rick: 9780786838653: Books - Amazon.ca. Available at: https://www.amazon.ca/Percy-Jackson-Olympians-Lightning-Thief/dp/0786838655 (Accessed: February 9, 2023). Which is located in: interests.html – line 28.
[8] 7 inch mini basketball (no date) Shop Hydropool.com. Available at: https://www.hydropool.com/cgi-bin/hydro/item/Premium-Game-Tables/7-inch-Mini-Basketball/NG2213.html (Accessed: February 9, 2023). Which is located in: interests.html – line 31.
[9] Temple isaiah's 18th annual Las Vegas night - Mercedes-Benz of smithtown (no date). Available at: https://www.mbofsmithtown.com/temple-isaiahs-18th-annual-las-vegas-night/ (Accessed: February 10, 2023). Which is located in: interests.html – line 43.
[10] Chicken adobo recipe: Knorr (no date) knorrv2 US. Available at: https://www.knorr.com/ph/recipe-ideas/chicken-adobo.html (Accessed: February 9, 2023). Which is located in: interests.html – line 46.
[11] Mmsuk (no date) Thanks for visiting gifs - get the best GIF on giphy, GIPHY. Available at: https://giphy.com/explore/thanks-for-visiting (Accessed: February 9, 2023). Which is located in: interests.html – line 80

Helpme.html contents:
[12] PlaceDog. (n.d.). Bark. woof. yap. Pooch-holders. Retrieved March 9, 2023, from https://placedog.net/ 
[13] Pinterest. (2020, October 18). DIY headboard, DIY headboards, color trends.  Retrieved March 9, 2023, from https://hips.hearstapps.com/hmg-prod/images/wolf-dog-breeds-siberian-husky-1570411330.jpg?crop=0.668xw:1.00xh
[14] Pixabay. (n.d.). 900+ free cat drawing & cat images - pixabay. Pixabay. Retrieved March 9, 2023, from https://pixabay.com/images/search/cat%20drawing/ 
[15] Humanesociety. (n.d.). An overview of caring for free-roaming cats - humane society. Humane Society. Retrieved March 9, 2023, from https://www.humanesociety.org/sites/default/files/docs/caring-feral-cats-overview.pdf 
[16] Pinterest. (2020, October 18). 29 Https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/color-trends-02-1503411059.png?resize=1600:* ideas: DIY headboard, DIY headboards, color trends. Pinterest. Retrieved March 9, 2023, from https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/cute-photos-of-cats-cuddling-1593203046.jpg



